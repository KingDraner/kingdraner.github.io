jQuery(document).ready(function() {
	"use strict";
	
	/*==========================================================
		 Pre-Loader
	==========================================================*/
	
	$(window).on('load', function() {
		// will first fade out the loading animation
		$(".preloader").fadeOut();
		//then background color will fade out slowly
		$(".preloader-wrapper").delay(200).fadeOut("slow");
	});
	
	/*==========================================================
		 Go To Top
	==========================================================*/
	
	$(window).scroll(function() {
	   if ($(this).scrollTop() > 200) {
		  $('#go-to-top a').fadeIn('slow');
		  } else {
		  $('#go-to-top a').fadeOut('slow');
		} 
	});
  
	$('#go-to-top a').on( "click",function(){
	  $("html,body").animate({ scrollTop: 0 }, 750);
	  return false;
	});
	
	/*==========================================================
		 WOW
	==========================================================*/
	
	var wow = new WOW(
	{
		mobile: false
	});
	wow.init();
	
	/*==========================================================
		 Scrolling Nav
	==========================================================*/
	
	$('header .nav').onePageNav({
		scrollThreshold: 0.2, // Adjust if Navigation highlights too early or too late
		scrollOffset: 100 //Height of Navigation Bar
	});
	
	$(window).scroll(function() {
	  
		//if (winWidth > 767) {
		var $scrollHeight = $(window).scrollTop();
		if ($scrollHeight > 600) {
			$('.navbar-home').slideDown(400);
		} else{
			$('.navbar-home').slideUp(400);
		}
	});
	
	$('#geo-navbar-collapse .nav a').on('click',function(){
		if($('.navbar-header .navbar-toggle').css('display') !='none'){
			$(".navbar-toggle").trigger( "click" );
		}
	});
	
	/*==========================================================
		 Text Slider On Banner
	==========================================================*/
	
	$('.flex_text').flexslider({
        animation: "slide",
		selector: ".slides li",
		controlNav: false,
		directionNav: false,
		slideshowSpeed: 4000,
		touch: true,
		useCSS: false,
		direction: "vertical",
        before: function(slider){        
		 var height = $('.flex_text').find('.flex-viewport').innerHeight();
		 $('.flex_text').find('li').css({ height: height + 'px' });
        }		
    });
	
	
	/*==========================================================
		Magnific Video Popup
	==========================================================*/
	
	$('.play').magnificPopup({
		disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: false
	});
	
	$.extend(true, $.magnificPopup.defaults, {
		iframe: {
			patterns: {
				youtube: {
					index: 'vimeo.com/', 
					id: 'v=', 
					src: 'http://vimeo.com/45830194' 
				}
			}
		}
	});
	
	/*==========================================================
		Scrrenshot Carousel
	==========================================================*/
	
	$(".screenshot-slider").owlCarousel({
		items: 1,
		loop: true,
		margin: 0,
		autoplay: true,
		autoplayTimeout: 3000,
		autoplayHoverPause: true,
		responsiveClass: true,
		responsive: {
			0: {
				items: 2
			},
			767: {
				items: 2
			},
			991: {
				items: 3
			},
			1199: {
				items: 4
			}
		}
	});
	
	/*==========================================================
		Newletter Subscribe
	==========================================================*/

	$(".newsletter-signup").ajaxChimp({
		callback: mailchimpResponse,
		url: "http://codepassenger.us10.list-manage.com/subscribe/post?u=6b2e008d85f125cf2eb2b40e9&id=6083876991" // Replace your mailchimp post url inside double quote "".  
	});

	function mailchimpResponse(resp) {
		 if(resp.result === 'success') {
		 
			$('.newsletter-success').html(resp.msg).fadeIn().delay(3000).fadeOut();
			
		} else if(resp.result === 'error') {
			$('.newsletter-error').html(resp.msg).fadeIn().delay(3000).fadeOut();
		}  
	};
	
	/*==========================================================
		Ajax Contact Form
	==========================================================*/
	
	// Function for email address validation
	function isValidEmail(emailAddress) {
	var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);

		return pattern.test(emailAddress);

	};
	$("#contact-form").on('submit', function(e) {
		e.preventDefault();
		var data = {
			name: $("#name").val(),
			email: $("#email").val(),
			// subject: $("#subject").val(),
			message: $("#message").val()
		};

		if ( isValidEmail(data['email']) && (data['message'].length > 1) && (data['name'].length > 1) ) {
			$.ajax({
				type: "POST",
				url: "sendmail.php",
				data: data,
				success: function() {
					$('#contact-form .input-success').delay(500).fadeIn(1000);
					$('#contact-form .input-error').fadeOut(500);
				}
			});
		} else {
			$('#contact-form .input-error').delay(500).fadeIn(1000);
			$('#contact-form .input-success').fadeOut(500);
		}

		return false;
	});
	
	
});
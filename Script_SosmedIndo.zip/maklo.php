<?php
### COPYRIGHT BY PENGETIK SOURCE A.K.A AHYAR DWI SETIAWAN ###

for($i=2; $i <= 150; $i++) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://irvankede-panel.com/price_list_pulsa.php");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$hh = curl_exec($ch);
curl_close($ch);

$dapat = explode('<tr>', $hh);
$data = explode('</tr>', $dapat[$i]);

$id  = explode('<th scope="row">', $data[0]);
$id = explode('</th>', $id[1]);

$services = explode('<td>', $data[0]);
$services = explode('</td>', $services[1]);

$prices = explode('<td>', $data[0]);
$prices = explode('</td>', $prices[2]);
$prices = str_replace("Rp", "", $prices);
$prices = str_replace(".","", $prices);

$min = explode('<td>', $data[0]);
$min = explode('</td>', $min[3]);
$min = str_replace(".", "", $min);


$max = explode('<td>', $data[0]);
$max = explode('</td>', $max[4]);
$max = str_replace(".", "", $max);

$hh = array("ID" => "".$id[0]."",
                        "Service" => "".$services[0]."",
                        "Prices/K" => "".$prices[0]."",
                        "Minimum" => "".$min[0]."",
                        "Maximum" => "".$max[0]."");
$hh = json_encode($hh);
$hh = json_decode($hh);

   print '<pre>'.print_r($hh,1).'</pre>';

//echo $data[0];
}
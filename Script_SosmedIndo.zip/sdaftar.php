<?php
/* HAK CIPTA 7hwID (7hw.info) 2016
* Hak eksklusif bagi pencipta atau penerima
* hak untuk mengumumkan atau memperbanyak ciptaannya
* atau memberikan izin untuk itu dengan tidak mengurangi
* pembatasan-pembatasan menurut peraturan perundang-undangan yang berlaku.
* Undang-undang Nomor 28 Tahun 2014
*/
session_start();
$_SESSION['captcha'] = rand(10000,100000);
?>                            <input class="form-control" type="hidden" name="captcha" value="<?php echo $_SESSION['captcha']; ?>">
											<button type="submit" class="pull-right btn btn-success btn-bordered waves-effect w-md waves-light" name="signup">Daftar</button>
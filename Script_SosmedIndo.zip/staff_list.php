<?php
session_start();
require("mainconfig.php");

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}
}

include("lib/header.php");
?>
<!-- Main content -->
			<section class="content container-fluid">
<div class="row">
	<div class="col-md-12">
		<h3 style="margin: 0 0 5px 0;"><i class="fa fa-phone"></i> Kontak</h3>
		<div class="alert alert-info"><i class="fa fa-info-circle"></i> Silahkan menghubungi kontak dibawah ini untuk informasi lebih lanjut.</div>
	</div>
	<div class="col-md-6">
		<div class="info-box">
			<span class="info-box-icon bg-default" style="line-height: 0;"><img src="http://irvankede-panelnew.com/assets/img/social/facebook.png" style="width: 50px; margin-top: 20px;"></span>
			<div class="info-box-content">
				<span class="info-box-text">Facebook</span>
                 <a class="btn btn-default btn-sm" href="https://m.facebook.com/FaiqqYahya"target="_blank">Muhamad Faiq</a>
			</div>
		</div>
		<div class="info-box">
			<span class="info-box-icon bg-default" style="line-height: 0;"><img src="http://irvankede-panelnew.com/assets/img/social/whatsapp.png" style="width: 50px; margin-top: 20px;"></span>
			<div class="info-box-content">
				<span class="info-box-text">Whatsapp</span>
				<a class="btn btn-default btn-sm" href="https://api.whatsapp.com/send?phone=082115866881"target="_blank">0821-1586-6881</a>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="info-box">
			<span class="info-box-icon bg-default" style="line-height: 0;"><img src="http://irvankede-panelnew.com/assets/img/social/instagram.png" style="width: 50px; margin-top: 20px;"></span>
			<div class="info-box-content">
				<span class="info-box-text">Instagram</span>
				<a class="btn btn-default btn-sm" href="https://www.instagram.com/official_sosmedindo/"target="_blank">@official_sosmedindo</a>
			</div>
		</div>
		<div class="info-box">
			<span class="info-box-icon bg-default" style="line-height: 0;"><img src="http://irvankede-panelnew.com/assets/img/social/line.png" style="width: 50px; margin-top: 20px;"></span>
			<div class="info-box-content">
				<span class="info-box-text">Line</span>
				<a class="btn btn-default btn-sm">-</a>
	    		</div>
    		</div>
    	</div>
    </div>
  </div>
</div>
						<!-- end row -->

                               
                               <div></div>

                              
</p>
                                </div>
                            </div>
                        </div>
                    </div>
						<!-- end row -->
<?php
include("lib/footer.php");
?>
<?php
session_start();
require("mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	$check_order = mysqli_query($db, "SELECT SUM(price) AS total FROM orders WHERE user = '$sess_username'");
	$data_order = mysqli_fetch_assoc($check_order);
	$count_users = mysqli_num_rows(mysqli_query($db, "SELECT * FROM users"));
} else {
	if (isset($_POST['login'])) {
		$post_username = mysqli_real_escape_string($db, trim($_POST['username']));
		$post_password = mysqli_real_escape_string($db, trim($_POST['password']));
		if (empty($post_username) || empty($post_password)) {
			$msg_type = "error";
			$msg_content = "<b>Gagal:</b> Mohon mengisi semua input.";
		} else {
			$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$post_username'");
			if (mysqli_num_rows($check_user) == 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Username atau password salah.";
			} else {
				$data_user = mysqli_fetch_assoc($check_user);
				if ($post_password <> $data_user['password']) {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> Username atau password salah.";
				} else if ($data_user['status'] == "Suspended") {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> Akun nonaktif.";
				} else {
					$_SESSION['user'] = $data_user;
					header("Location: dashboard.php");
				}
			}
		}
	}
}

include("lib/header.php");
if (isset($_SESSION['user'])) {
?>
<?php
} else {
?> 

 <div class="alert alert-info">
<marquee direction="left" scrollamount="10" align="center"><font color="black">
<b> Selamat Datang di <high> SosmedIndo-Panel</high> , disini kami menyediakan berbagai layanan mulai dari Sosial Media, Voucher Game, Token Listrik, Pulsa Elektrik, dan masih banyak lagi.
</b></font></marquee>
</div>
						<div class="row">
							<div class="col-md-offset-2 col-md-8">
								<div class="panel panel-default">
									<div class="panel-heading">
										<h3 class="panel-title"><i class="fa fa-user"></i> Masuk</h3>
									</div>
									<div class="panel-body">
										<?php 
										if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Username</label>
												<div class="col-md-10">
													<input type="text" name="username" class="form-control" placeholder="Username">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Password</label>
												<div class="col-md-10">
													<input type="password" name="password" class="form-control" placeholder="Password">
												</div>
											</div>
</div>
<div class="form-group">
<div class="col-sm-offset-3 col-sm-9">
<div class="checkbox">
<label>
<input type="checkbox" name="remember" value="true"> Ingat saya
</label>
</div>
</div>
<div class="box-footer">
<a href="http://sosmedindo-panel.xyz/signup" class="btn btn-default"><i class="fa fa-user-plus"></i> Daftar</a>
<button type="submit" class="btn btn-info pull-right" name="login" value="1"><i class="fa fa-unlock"></i> Masuk</button>
</div>
									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
						
<?php
}
include("lib/footer.php");
?>
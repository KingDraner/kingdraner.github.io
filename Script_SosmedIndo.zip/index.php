<?php
//------------//
// Alberts.ac//
//----------//
ob_start();
session_start();
if(!isset($_SESSION['username'])) {
	header('location:welcome');
} else
require("mainconfig.php");
$msg_type = "nothing";

if (isset($_SESSION['user'])) {
	$sess_username = $_SESSION['user']['username'];
	$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$sess_username'");
	$data_user = mysqli_fetch_assoc($check_user);
	if (mysqli_num_rows($check_user) == 0) {
		header("Location: ".$cfg_baseurl."logout.php");
	} else if ($data_user['status'] == "Suspended") {
		header("Location: ".$cfg_baseurl."logout.php");
	}

	$check_order = mysqli_query($db, "SELECT SUM(price) AS total FROM orders WHERE user = '$sess_username'");
	$data_order = mysqli_fetch_assoc($check_order);
	$count_users = mysqli_num_rows(mysqli_query($db, "SELECT * FROM users"));
} else {
	if (isset($_POST['login'])) {
		$post_username = mysqli_real_escape_string($db, trim($_POST['username']));
		$post_password = mysqli_real_escape_string($db, trim($_POST['password']));
		if (empty($post_username) || empty($post_password)) {
			$msg_type = "error";
			$msg_content = "<b>Gagal:</b> Mohon mengisi semua input.";
		} else {
			$check_user = mysqli_query($db, "SELECT * FROM users WHERE username = '$post_username'");
			if (mysqli_num_rows($check_user) == 0) {
				$msg_type = "error";
				$msg_content = "<b>Gagal:</b> Username atau password salah.";
			} else {
				$data_user = mysqli_fetch_assoc($check_user);
				if ($post_password <> $data_user['password']) {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> Username atau password salah.";
				} else if ($data_user['status'] == "Suspended") {
					$msg_type = "error";
					$msg_content = "<b>Gagal:</b> Akun nonaktif.";
				} else {
					$_SESSION['user'] = $data_user;
					header("Location: ".$cfg_baseurl);
				}
			}
		}
	}
}

include("lib/header.php");
if (isset($_SESSION['user'])) {
?>

<div class="callout callout-info">
							<h4><i class="fa fa-bullhorn"></i> Selamat datang <?php echo $sess_username; ?></h4>
							<p>Selamat berbelanja!</p>
						</div>	
	<div class="box-header with-border">
				<h3 class="box-title"><i class="fa fa-line-chart"></i> Pesanan 7 hari terakhir</h3>
			</div>									          <div class="row">
	<svg height="250" version="1.1" width="310" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="overflow: hidden; position: relative;"><desc style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Created with Raphaël 2.2.0</desc><defs style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></defs><text x="35.859375" y="193.65845101492187" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="3.658451014921866" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">0</tspan></text><path fill="none" stroke="#aaaaaa" d="M48.359375,193.65845101492187H285" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="35.859375" y="151.4938382611914" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="3.6657132611913994" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">0.25</tspan></text><path fill="none" stroke="#aaaaaa" d="M48.359375,151.4938382611914H285" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="35.859375" y="109.32922550746093" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="3.657350507460933" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">0.5</tspan></text><path fill="none" stroke="#aaaaaa" d="M48.359375,109.32922550746093H285" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="35.859375" y="67.16461275373047" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="3.6646127537304665" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">0.75</tspan></text><path fill="none" stroke="#aaaaaa" d="M48.359375,67.16461275373047H285" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="35.859375" y="25" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal"><tspan dy="3.65625" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">1</tspan></text><path fill="none" stroke="#aaaaaa" d="M48.359375,25H285" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><text x="285" y="206.15845101492187" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(0.9397,-0.342,0.342,0.9397,-81.7555,126.8324)"><tspan dy="3.658451014921866" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2018-02-12</tspan></text><text x="206.11979166666666" y="206.15845101492187" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(0.9397,-0.342,0.342,0.9397,-86.5132,99.8503)"><tspan dy="3.658451014921866" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2018-02-10</tspan></text><text x="127.23958333333333" y="206.15845101492187" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#888888" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(0.9397,-0.342,0.342,0.9397,-91.2699,72.8734)"><tspan dy="3.658451014921866" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2018-02-08</tspan></text><path fill="none" stroke="#129bf4" d="M48.359375,193.65845101492187C58.219401041666664,193.65845101492187,77.939453125,193.65845101492187,87.79947916666666,193.65845101492187C97.65950520833333,193.65845101492187,117.37955729166666,193.65845101492187,127.23958333333333,193.65845101492187C137.099609375,193.65845101492187,156.81966145833334,193.65845101492187,166.6796875,193.65845101492187C176.53971354166666,193.65845101492187,196.259765625,193.65845101492187,206.11979166666666,193.65845101492187C215.97981770833331,172.57614463805663,235.69986979166669,46.08230637686524,245.55989583333334,25C255.419921875,3.917693623134774,275.1399739583333,25,285,25" stroke-width="3" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path><circle cx="48.359375" cy="193.65845101492187" r="7" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="87.79947916666666" cy="193.65845101492187" r="4" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="127.23958333333333" cy="193.65845101492187" r="4" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="166.6796875" cy="193.65845101492187" r="4" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="206.11979166666666" cy="193.65845101492187" r="4" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="245.55989583333334" cy="25" r="4" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle><circle cx="285" cy="25" r="4" fill="#129bf4" stroke="#ffffff" stroke-width="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></circle></svg>	
<section class="content">
      <div class="row">
        <div class="col-md-4">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Seluruh Pembelian Pengguna</span>
              <span class="info-box-number">Rp <?php echo number_format($data_worder['total'],0,',','.'); ?> (Dari <?php echo number_format($count_worder,0,',','.'); ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
              <span class="progress-description">
                    Dari 3.671 Pesanan
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4">
          <div class="info-box bg-green">
            <span class="info-box-icon"><i class="fa fa-shopping-cart"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Pemakaian Saldo Social Media</span>
              <span class="info-box-number">Rp <?php echo number_format($data_order['total'],0,',','.'); ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
              <span class="progress-description">
                    Dari <?php echo number_format($data_order['total'],0,',','.'); ?> Pembelian
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4">
          <div class="info-box bg-red">
            <span class="info-box-icon"><i class="fa fa-shopping-cart"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"> Total Pemakaian Saldo Pulsa,Voucher,Dll</span>
              <span class="info-box-number">Rp <?php echo number_format($data_order['total'],0,',','.'); ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
              <span class="progress-description">
                    Dari <?php echo number_format($data_order['total'],0,',','.'); ?> Pembelian
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
          </div>
     <div class="row">
        <div class="col-md-4">
          <div class="box">
            <div class="box-header">
              <i class="fa fa-user"></i>

              <h3 class="box-title">Detail Akun <?php echo $sess_username; ?></h3>

             
            </div>
            <div class="box-body">  
            <table class="table table-bordered">
              <tbody><tr>
                <td>Username</td>
                <td><?php echo $sess_username; ?></td>
              </tr                    
              <tr>
                <td>Sisa Saldo</td>
                <td>Rp  <?php echo number_format($data_user['balance'],0,',','.'); ?></td>
              </tr>
              <tr>
                <td>Total Pembelian</td>
                <td>Rp <?php echo number_format($data_order['total'],0,',','.'); ?></td>
              </tr>
            
            </tbody></table>
          </div>
           </div>
           </div>

        

          
							
									
		
						
							<div class="row">
								<div class="col-md-12">
									<div class="panel panel-default">
										<div class="panel-heading">
											<h3 class="panel-title"><i class="fa fa-newspaper-o"></i> BERITA & INFORMASI</h3>
										</div>
										<div class="panel-body">
											<div class="table-responsive">
												<table class="table table-striped table-bordered table-hover m-0">
													<thead>
							
													<tr>
														<th>#</th>
														<th>Tanggal</th>
														<th>Isi</th>
													</tr>
												</thead>
												<tbody>
													<?php
													$check_news = mysqli_query($db, "SELECT * FROM news ORDER BY id DESC LIMIT 5");
													$no = 1;
													while ($data_news = mysqli_fetch_assoc($check_news)) {
													?>
													<tr>
														<th scope="row"><?php echo $no; ?></th>
														<td><?php echo $data_news['date']; ?></td>
														<td><?php echo $data_news['content']; ?></td>
													</tr>
													<?php
													$no++;
													}
													?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					
						<!--end row -->
<?php
} else {
?> 
 <div class="alert alert-info">
<marquee direction="left" scrollamount="10" align="center"><font color="black">
<b> Selamat Datang di <high> SosmedIndo-Panel</high> , disini kami menyediakan berbagai layanan mulai dari Sosial Media, Voucher Game, Token Listrik, Pulsa Elektrik, dan masih banyak lagi.
</b></font></marquee>
</div>
						<div class="row">
							<div class="col-md-offset-2 col-md-8">
								<div class="panel panel-default">
									<div class="panel-heading">
										<h3 class="panel-title"><i class="fa fa-user"></i> Masuk</h3>
									</div>
									<div class="panel-body">
										<?php 
										if ($msg_type == "error") {
										?>
										<div class="alert alert-danger">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
											<i class="fa fa-times-circle"></i>
											<?php echo $msg_content; ?>
										</div>
										<?php
										}
										?>
										<form class="form-horizontal" role="form" method="POST">
											<div class="form-group">
												<label class="col-md-2 control-label">Username</label>
												<div class="col-md-10">
													<input type="text" name="username" class="form-control" placeholder="Username">
												</div>
											</div>
											<div class="form-group">
												<label class="col-md-2 control-label">Password</label>
												<div class="col-md-10">
													<input type="password" name="password" class="form-control" placeholder="Password">
												</div>
											</div>
</div>
<div class="form-group">
<div class="col-sm-offset-3 col-sm-9">
<div class="checkbox">
<label>
<input type="checkbox" name="remember" value="true"> Ingat saya
</label>
</div>
</div>
<div class="box-footer">
<a href="http://sosmedindo-panel.xyz/signup" class="btn btn-default"><i class="fa fa-user-plus"></i> Daftar</a>
<button type="submit" class="btn btn-info pull-right" name="login" value="1"><i class="fa fa-unlock"></i> Masuk</button>

									</div>
								</div>
							</div>
						</div>
						<!-- end row -->
						
<?php
}
include("lib/footer.php");
?>